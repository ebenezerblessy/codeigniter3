Instructions:
First download and install composer in your computer. 
Without running composer your vendor folder will not installed.
Copy or clone this repository files to xampp/htdocs/yourfolder . 
In VScode or any terminal change your path to your project root folder and type command "compose install".
