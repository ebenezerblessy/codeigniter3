<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Email extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('upload'); // Load the upload library to handle file uploads
    }

    public function index() {
        // Load the contact form view
        $this->load->view('contact_form');
    }

    public function send_email() {
        // Get form input
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $subject = $this->input->post('subject');
        $message = $this->input->post('message');

        // Initialize the attachment file path variable
        $file_path = null;
        $attachment_name = null;

        // Handle file upload (if any)
        if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
            // Set upload configuration
            $config['upload_path'] = './uploads/';  // Directory to save uploaded files
            $config['allowed_types'] = 'jpg|png|jpeg|pdf|doc|docx|txt'; // Allowed file types
            $config['max_size'] = 10240; // Max file size (in KB)
            $config['file_name'] = uniqid(); // Unique file name to avoid collisions

            // Initialize the upload library with the configuration
            $this->upload->initialize($config);

            // Attempt to upload the file
            if ($this->upload->do_upload('attachment')) {
                $upload_data = $this->upload->data();
                $file_path = $upload_data['full_path']; // Get the full path of the uploaded file
                $attachment_name = $upload_data['file_name']; // Get the uploaded file's name
            } else {
                // If upload fails, display the error
                echo $this->upload->display_errors();
                return;
            }
        }

        // Sender and receiver email addresses
        $from_address = "testapplication@harinco.in"; // Your email address
        $to_address = "testapplication@harinco.in"; // Receiver email address

        // Construct email body in HTML format
        $body = "<html>
                    <style>
                        table, th, td {
                            border-collapse: collapse;
                            border: 1px solid black;
                        }
                    </style>
                    <body>
                        <p>Someone has contacted you!</p>
                        <br><br>
                        <h3>Sender Details</h3><br>
                        <table>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Message</th>
                                <th>Attachment</th>
                            </tr>
                            <tr>
                                <td>" . htmlspecialchars($name) . "</td>
                                <td>" . htmlspecialchars($email) . "</td>
                                <td>" . nl2br(htmlspecialchars($message)) . "</td>
                                <td>" . ($attachment_name ? htmlspecialchars($attachment_name) : 'No attachment') . "</td>
                            </tr>
                        </table>
                    </body>
                </html>";

        // Create PHPMailer instance
        $mailer = new PHPMailer(true);

        try {
            // Set mailer to use SMTP
            $mailer->isSMTP();
            $mailer->Host = "smtp.office365.com"; // Gmail SMTP server
            $mailer->SMTPAuth = true;
            $mailer->Username = "testapplication@harinco.in"; // Your Gmail address
            $mailer->Password = "QeZt6J6x"; // Use app password (NOT your Gmail password)
            $mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use STARTTLS encryption
            $mailer->Port = 587; // Port for STARTTLS

            // Set sender and recipient
            $mailer->setFrom($from_address, $name);
            $mailer->addAddress($to_address);

            // Set email subject and body
            $mailer->Subject = $subject;
            $mailer->isHTML(true);
            $mailer->Body = $body;

            // Attach the uploaded file (if any)
            if ($file_path) {
                $mailer->addAttachment($file_path, $attachment_name); // Attach the uploaded file with the name
            }

            // Enable debugging (useful for development)
            $mailer->SMTPDebug = 2; // Detailed debug output

            // Send the email
            if ($mailer->send()) {
                echo "Mail has been sent successfully!";
            }
        } catch (Exception $e) {
            // Display error message in case of failure
            echo "Mail Error: " . $mailer->ErrorInfo; // Detailed error info
        }
    }
}
?>
